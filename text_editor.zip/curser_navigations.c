#include <stdio.h>
#include <string.h>
#include "curser_navigations.h"

void moveCursorUp(TextEditor *editor)
{
    if (editor->cursor->prev) {
        editor->cursor = editor->cursor->prev;
        updateCursorLine(editor);
    } else printf("Already at first line.\n");
}

void moveCursorDown(TextEditor *editor)
{
    if (editor->cursor->next) {
        editor->cursor = editor->cursor->next;
        updateCursorLine(editor);
    } else printf("Already at last line.\n");
}

void moveCursorLeft(TextEditor *editor)
{
    if (editor->cursorPos > 0)
        --editor->cursorPos;
    else
        printf("Already at beginning of line.\n");
}

void moveCursorRight(TextEditor *editor)
{
    if (editor->cursorPos < (int)strlen(editor->cursor->text))
        ++editor->cursorPos;
    else
        printf("Already at end of line.\n");
}

void jumpToStartOfFile(TextEditor *editor)
{
    editor->cursor = editor->head;
    editor->cursorPos = 0;
    updateCursorLine(editor);
}

void jumpToEndOfFile(TextEditor *editor)
{
    editor->cursor = editor->tail;
    editor->cursorPos = (int)strlen(editor->cursor->text);
    updateCursorLine(editor);
}

void jumpToStartOfLine(TextEditor *editor)
{
    editor->cursorPos = 0;
}

void jumpToEndOfLine(TextEditor *editor)
{
    editor->cursorPos = (int)strlen(editor->cursor->text);
}
