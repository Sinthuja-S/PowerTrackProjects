#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "text_ops.h"

extern Node *textEditorCreateNode(const char *text);
extern void textEditorInsertNodeAfter(TextEditor *e, Node *c, Node *n);
extern void textEditorDeleteNode(TextEditor *e, Node *n);

static char *dupstr(const char *s)
{
    char *p = malloc(strlen(s) + 1);
    if (!p) exit(EXIT_FAILURE);
    strcpy(p, s);
    return p;
}

static void clearRedo(TextEditor *editor)
{
    clearStack(&editor->redoStack);
}

void insertText(TextEditor *editor, const char *text, int recordHistory)
{
    char *newText;
    size_t oldLen, addLen, pos;

    if (!text || !*text)
        return;

    /* A newline creates additional linked-list lines. */
    {
        char *copy = dupstr(text);
        char *part = strtok(copy, "\n");
        int first = 1;

        while (part) {
            oldLen = strlen(editor->cursor->text);
            pos = (size_t)editor->cursorPos;
            addLen = strlen(part);

            newText = malloc(oldLen + addLen + 1);
            if (!newText) exit(EXIT_FAILURE);

            memcpy(newText, editor->cursor->text, pos);
            memcpy(newText + pos, part, addLen);
            strcpy(newText + pos + addLen,
                   editor->cursor->text + pos);

            free(editor->cursor->text);
            editor->cursor->text = newText;
            editor->cursorPos += (int)addLen;

            if (strtok(NULL, "\n") != NULL) {
                char *remaining = dupstr(editor->cursor->text + editor->cursorPos);
                Node *newNode = textEditorCreateNode(remaining);
                free(remaining);

                editor->cursor->text[editor->cursorPos] = '\0';
                textEditorInsertNodeAfter(editor, editor->cursor, newNode);
                editor->cursor = newNode;
                editor->cursorPos = 0;
            }

            part = strtok(NULL, "\n");
            if (!first) break;
            first = 0;
        }

        free(copy);
    }

    updateCursorLine(editor);

    if (recordHistory) {
        /* Store the original text and original location. */
        int originalPos = editor->cursorPos - (int)strlen(text);
        if (originalPos < 0) originalPos = 0;
        pushStack(&editor->undoStack, "insert", text,
                  editor->cursorLine, originalPos);
        clearRedo(editor);
    }
}

void deleteCharacters(TextEditor *editor, int count, int recordHistory)
{
    size_t len, available, n;
    char *deleted, *newText;

    if (count <= 0) {
        printf("Invalid number of characters.\n");
        return;
    }

    len = strlen(editor->cursor->text);
    if ((size_t)editor->cursorPos >= len) {
        printf("Nothing to delete.\n");
        return;
    }

    available = len - (size_t)editor->cursorPos;
    n = (size_t)count < available ? (size_t)count : available;

    deleted = malloc(n + 1);
    newText = malloc(len - n + 1);
    if (!deleted || !newText) exit(EXIT_FAILURE);

    memcpy(deleted, editor->cursor->text + editor->cursorPos, n);
    deleted[n] = '\0';

    memcpy(newText, editor->cursor->text, editor->cursorPos);
    strcpy(newText + editor->cursorPos,
           editor->cursor->text + editor->cursorPos + n);

    free(editor->cursor->text);
    editor->cursor->text = newText;

    if (recordHistory) {
        pushStack(&editor->undoStack, "delete", deleted,
                  editor->cursorLine, editor->cursorPos);
        clearRedo(editor);
    }

    free(deleted);
}

void copyText(TextEditor *editor, int count)
{
    size_t available, n;

    free(editor->clipboard);
    editor->clipboard = NULL;

    available = strlen(editor->cursor->text) -
                (size_t)editor->cursorPos;

    if (!available) {
        printf("Nothing to copy.\n");
        return;
    }

    n = (size_t)count < available ? (size_t)count : available;
    editor->clipboard = malloc(n + 1);
    if (!editor->clipboard) exit(EXIT_FAILURE);

    memcpy(editor->clipboard,
           editor->cursor->text + editor->cursorPos, n);
    editor->clipboard[n] = '\0';

    printf("Copied: \"%s\"\n", editor->clipboard);
}

void cutText(TextEditor *editor, int count)
{
    copyText(editor, count);
    if (editor->clipboard)
        deleteCharacters(editor, count, 1);
}

void pasteText(TextEditor *editor)
{
    if (!editor->clipboard) {
        printf("Clipboard is empty.\n");
        return;
    }
    insertText(editor, editor->clipboard, 1);
}
