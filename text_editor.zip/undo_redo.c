#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "text_editor.h"
#include "text_ops.h"

static Node *findLine(TextEditor *editor, int line)
{
    Node *p = editor->head;
    int n = 1;

    while (p && n < line) {
        p = p->next;
        ++n;
    }
    return p;
}

void undoEditor(TextEditor *editor)
{
    Action a;

    if (isStackEmpty(&editor->undoStack)) {
        printf("Nothing to undo.\n");
        return;
    }

    a = popStack(&editor->undoStack);

    editor->cursor = findLine(editor, a.line);
    if (!editor->cursor) {
        free(a.text);
        return;
    }

    editor->cursorLine = a.line;
    editor->cursorPos = a.position;

    if (strcmp(a.operation, "insert") == 0) {
        deleteCharacters(editor, (int)strlen(a.text), 0);
    } else if (strcmp(a.operation, "delete") == 0) {
        insertText(editor, a.text, 0);
    }

    pushStack(&editor->redoStack, a.operation, a.text,
              a.line, a.position);

    free(a.text);
    printf("Undo operation successful.\n");
}

void redoEditor(TextEditor *editor)
{
    Action a;

    if (isStackEmpty(&editor->redoStack)) {
        printf("Nothing to redo.\n");
        return;
    }

    a = popStack(&editor->redoStack);

    editor->cursor = findLine(editor, a.line);
    if (!editor->cursor) {
        free(a.text);
        return;
    }

    editor->cursorLine = a.line;
    editor->cursorPos = a.position;

    if (strcmp(a.operation, "insert") == 0) {
        insertText(editor, a.text, 0);
    } else if (strcmp(a.operation, "delete") == 0) {
        deleteCharacters(editor, (int)strlen(a.text), 0);
    }

    pushStack(&editor->undoStack, a.operation, a.text,
              a.line, a.position);

    free(a.text);
    printf("Redo operation successful.\n");
}
