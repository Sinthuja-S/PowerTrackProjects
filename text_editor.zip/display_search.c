#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "display_search.h"

void findText(TextEditor *editor, const char *search)
{
    Node *current = editor->head;
    int line = 1, found = 0;

    if (!search || !*search) {
        printf("Search text cannot be empty.\n");
        return;
    }

    while (current) {
        char *p = current->text;

        while ((p = strstr(p, search)) != NULL) {
            printf("Found \"%s\" at Line %d, Column %ld\n",
                   search, line, (long)(p - current->text));
            ++found;
            p += strlen(search);
        }

        current = current->next;
        ++line;
    }

    printf("Search completed. %d match(es) found.\n", found);
}

void replaceText(TextEditor *editor, const char *search,
                 const char *replacement)
{
    Node *current = editor->head;
    int count = 0;

    if (!search || !*search) {
        printf("Search text cannot be empty.\n");
        return;
    }

    while (current) {
        char *p;

        while ((p = strstr(current->text, search)) != NULL) {
            size_t oldLen = strlen(current->text);
            size_t searchLen = strlen(search);
            size_t replLen = strlen(replacement);
            size_t prefix = (size_t)(p - current->text);

            char *newText =
                malloc(oldLen - searchLen + replLen + 1);

            if (!newText) exit(EXIT_FAILURE);

            memcpy(newText, current->text, prefix);
            memcpy(newText + prefix, replacement, replLen);
            strcpy(newText + prefix + replLen, p + searchLen);

            free(current->text);
            current->text = newText;
            ++count;
        }

        current = current->next;
    }

    printf("Replaced %d occurrence(s).\n", count);
}
