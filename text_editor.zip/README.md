# TestEditor - C Console Text Editor

## Files

- text_editor.c / text_editor.h - main controller and editor structure
- text_ops.c / text_ops.h - insert, delete, copy, cut, paste
- curser_navigations.c / curser_navigations.h - cursor movement
- file_ops.c / file_ops.h - open and save
- display_search.c / display_search.h - display, find, replace
- redo_undo.c / redo_undo.h - dynamic array stack
- undo_redo.c - undo and redo operations
- Makefile - build automation

## Compile

```bash
make
```

Or:

```bash
gcc -std=c99 -Wall -Wextra text_editor.c text_ops.c \
curser_navigations.c file_ops.c display_search.c \
redo_undo.c undo_redo.c -o text_editor
```

## Run

```bash
./text_editor
```

Type `help` inside the program to see all commands.
