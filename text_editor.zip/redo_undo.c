#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "redo_undo.h"

#define INITIAL_STACK_SIZE 10

static char *duplicateString(const char *str)
{
    char *copy = malloc(strlen(str) + 1);
    if (!copy) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
    strcpy(copy, str);
    return copy;
}

void initializeStack(DynamicArrayStack *stack)
{
    stack->size = 0;
    stack->capacity = INITIAL_STACK_SIZE;
    stack->actions = malloc(stack->capacity * sizeof(Action));

    if (!stack->actions) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
}

void clearStack(DynamicArrayStack *stack)
{
    int i;
    for (i = 0; i < stack->size; ++i)
        free(stack->actions[i].text);

    stack->size = 0;
}

void destroyStack(DynamicArrayStack *stack)
{
    clearStack(stack);
    free(stack->actions);
    stack->actions = NULL;
}

void pushStack(DynamicArrayStack *stack, const char *operation,
               const char *text, int line, int position)
{
    Action *tmp;

    if (stack->size == stack->capacity) {
        stack->capacity *= 2;
        tmp = realloc(stack->actions,
                      stack->capacity * sizeof(Action));
        if (!tmp) {
            fprintf(stderr, "Unable to resize stack.\n");
            exit(EXIT_FAILURE);
        }
        stack->actions = tmp;
    }

    strncpy(stack->actions[stack->size].operation,
            operation,
            sizeof(stack->actions[stack->size].operation) - 1);
    stack->actions[stack->size].operation[
        sizeof(stack->actions[stack->size].operation) - 1] = '\0';

    stack->actions[stack->size].text = duplicateString(text);
    stack->actions[stack->size].line = line;
    stack->actions[stack->size].position = position;
    stack->size++;
}

int isStackEmpty(DynamicArrayStack *stack)
{
    return stack->size == 0;
}

Action popStack(DynamicArrayStack *stack)
{
    Action empty = {{0}, NULL, 0, 0};

    if (stack->size == 0)
        return empty;

    return stack->actions[--stack->size];
}
