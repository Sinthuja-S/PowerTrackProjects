#ifndef REDO_UNDO_H
#define REDO_UNDO_H

typedef struct {
    char operation[20];
    char *text;
    int line;
    int position;
} Action;

typedef struct {
    Action *actions;
    int size;
    int capacity;
} DynamicArrayStack;

void initializeStack(DynamicArrayStack *stack);
void clearStack(DynamicArrayStack *stack);
void destroyStack(DynamicArrayStack *stack);
void pushStack(DynamicArrayStack *stack, const char *operation,
               const char *text, int line, int position);
int isStackEmpty(DynamicArrayStack *stack);
Action popStack(DynamicArrayStack *stack);

#endif
