#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "file_ops.h"

static void appendLine(TextEditor *editor, const char *text)
{
    Node *node = malloc(sizeof(Node));
    if (!node) exit(EXIT_FAILURE);

    node->text = malloc(strlen(text) + 1);
    if (!node->text) exit(EXIT_FAILURE);

    strcpy(node->text, text);
    node->next = NULL;
    node->prev = editor->tail;

    editor->tail->next = node;
    editor->tail = node;
}

int openFile(TextEditor *editor, const char *filename)
{
    FILE *fp = fopen(filename, "r");
    char buffer[1024];
    int first = 1;

    if (!fp) {
        printf("Error: File '%s' not found.\n", filename);
        return 0;
    }

    clearDocument(editor);

    while (fgets(buffer, sizeof(buffer), fp)) {
        size_t len = strlen(buffer);

        if (len && buffer[len - 1] == '\n')
            buffer[len - 1] = '\0';

        if (first) {
            free(editor->head->text);
            editor->head->text = malloc(strlen(buffer) + 1);
            if (!editor->head->text) exit(EXIT_FAILURE);
            strcpy(editor->head->text, buffer);
            first = 0;
        } else {
            appendLine(editor, buffer);
        }
    }

    fclose(fp);

    editor->cursor = editor->head;
    editor->cursorPos = 0;
    updateCursorLine(editor);

    printf("File '%s' opened successfully.\n", filename);
    return 1;
}

int saveFile(TextEditor *editor, const char *filename)
{
    FILE *fp = fopen(filename, "w");
    Node *current;

    if (!fp) {
        printf("Error: Cannot open file for writing.\n");
        return 0;
    }

    current = editor->head;
    while (current) {
        fprintf(fp, "%s", current->text);
        if (current->next)
            fputc('\n', fp);
        current = current->next;
    }

    fclose(fp);
    printf("File '%s' saved successfully.\n", filename);
    return 1;
}
