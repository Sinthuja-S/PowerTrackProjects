#ifndef DISPLAY_SEARCH_H
#define DISPLAY_SEARCH_H

#include "text_editor.h"

void findText(TextEditor *editor, const char *search);
void replaceText(TextEditor *editor, const char *search,
                 const char *replacement);

#endif
