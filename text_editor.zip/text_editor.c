#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "text_editor.h"
#include "text_ops.h"
#include "curser_navigations.h"
#include "file_ops.h"
#include "display_search.h"

static char *duplicateString(const char *str)
{
    char *copy = malloc(strlen(str) + 1);
    if (!copy) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
    strcpy(copy, str);
    return copy;
}

static Node *createNode(const char *text)
{
    Node *node = malloc(sizeof(Node));
    if (!node) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }

    node->text = duplicateString(text);
    node->prev = NULL;
    node->next = NULL;
    return node;
}

static void insertNodeAfter(TextEditor *editor, Node *current, Node *node)
{
    node->prev = current;
    node->next = current->next;

    if (current->next)
        current->next->prev = node;
    else
        editor->tail = node;

    current->next = node;
}

static void deleteNode(TextEditor *editor, Node *node)
{
    if (!node)
        return;

    if (node->prev)
        node->prev->next = node->next;
    else
        editor->head = node->next;

    if (node->next)
        node->next->prev = node->prev;
    else
        editor->tail = node->prev;

    free(node->text);
    free(node);
}

void initializeEditor(TextEditor *editor)
{
    Node *node = createNode("");

    editor->head = node;
    editor->tail = node;
    editor->cursor = node;
    editor->cursorLine = 1;
    editor->cursorPos = 0;
    editor->clipboard = NULL;

    initializeStack(&editor->undoStack);
    initializeStack(&editor->redoStack);
}

int getLineNumber(TextEditor *editor, Node *node)
{
    int line = 1;
    Node *current = editor->head;

    while (current) {
        if (current == node)
            return line;
        current = current->next;
        ++line;
    }
    return 1;
}

void updateCursorLine(TextEditor *editor)
{
    editor->cursorLine = getLineNumber(editor, editor->cursor);

    if (editor->cursorPos > (int)strlen(editor->cursor->text))
        editor->cursorPos = (int)strlen(editor->cursor->text);
}

void clearDocument(TextEditor *editor)
{
    Node *current = editor->head;

    while (current) {
        Node *next = current->next;
        free(current->text);
        free(current);
        current = next;
    }

    editor->head = editor->tail = editor->cursor = createNode("");
    editor->cursorLine = 1;
    editor->cursorPos = 0;

    clearStack(&editor->undoStack);
    clearStack(&editor->redoStack);
}

void freeEditor(TextEditor *editor)
{
    Node *current = editor->head;

    while (current) {
        Node *next = current->next;
        free(current->text);
        free(current);
        current = next;
    }

    free(editor->clipboard);
    destroyStack(&editor->undoStack);
    destroyStack(&editor->redoStack);
}

void displayText(TextEditor *editor)
{
    Node *current = editor->head;
    int line = 1;

    printf("\n============================================================\n");
    while (current) {
        printf("Line %-4d: %s\n", line++, current->text);
        current = current->next;
    }
    printf("------------------------------------------------------------\n");
    printf("Cursor position: Line %d, Column %d\n",
           editor->cursorLine, editor->cursorPos);
    printf("============================================================\n");
}

void showCursorPosition(TextEditor *editor)
{
    printf("Cursor position: Line %d, Column %d\n",
           editor->cursorLine, editor->cursorPos);
}

void printHelp(void)
{
    printf("\nText Editor Commands\n");
    printf("--------------------\n");
    printf("insert <text>          Insert text\n");
    printf("delete <number>        Delete characters\n");
    printf("copy <number>          Copy characters\n");
    printf("cut <number>           Cut characters\n");
    printf("paste                  Paste clipboard\n");
    printf("undo                   Undo last operation\n");
    printf("redo                   Redo last operation\n");
    printf("up                     Move cursor up\n");
    printf("down                   Move cursor down\n");
    printf("left                   Move cursor left\n");
    printf("right                  Move cursor right\n");
    printf("home                   Start of line\n");
    printf("end                    End of line\n");
    printf("top                    Start of file\n");
    printf("bottom                 End of file\n");
    printf("find <text>            Search text\n");
    printf("replace <old> <new>    Replace text\n");
    printf("open <filename>        Open file\n");
    printf("save <filename>        Save file\n");
    printf("print                  Display document\n");
    printf("position               Show cursor position\n");
    printf("help                   Show commands\n");
    printf("exit                   Exit\n\n");
}

void handleCommand(TextEditor *editor, char *input)
{
    char command[50];
    char arg[1024];

    if (sscanf(input, "%49s", command) != 1)
        return;

    if (strcmp(command, "insert") == 0) {
        char *text = input + strlen(command);
        while (*text == ' ') ++text;
        insertText(editor, text, 1);
    }
    else if (strcmp(command, "delete") == 0) {
        int n;
        if (sscanf(input + strlen(command), "%d", &n) == 1)
            deleteCharacters(editor, n, 1);
        else
            printf("Usage: delete <number>\n");
    }
    else if (strcmp(command, "copy") == 0) {
        int n;
        if (sscanf(input + strlen(command), "%d", &n) == 1)
            copyText(editor, n);
        else
            printf("Usage: copy <number>\n");
    }
    else if (strcmp(command, "cut") == 0) {
        int n;
        if (sscanf(input + strlen(command), "%d", &n) == 1)
            cutText(editor, n);
        else
            printf("Usage: cut <number>\n");
    }
    else if (strcmp(command, "paste") == 0) {
        pasteText(editor);
    }
    else if (strcmp(command, "undo") == 0) {
        undoEditor(editor);
    }
    else if (strcmp(command, "redo") == 0) {
        redoEditor(editor);
    }
    else if (strcmp(command, "print") == 0) {
        displayText(editor);
    }
    else if (strcmp(command, "position") == 0) {
        showCursorPosition(editor);
    }
    else if (strcmp(command, "up") == 0) {
        moveCursorUp(editor);
    }
    else if (strcmp(command, "down") == 0) {
        moveCursorDown(editor);
    }
    else if (strcmp(command, "left") == 0) {
        moveCursorLeft(editor);
    }
    else if (strcmp(command, "right") == 0) {
        moveCursorRight(editor);
    }
    else if (strcmp(command, "home") == 0) {
        jumpToStartOfLine(editor);
    }
    else if (strcmp(command, "end") == 0) {
        jumpToEndOfLine(editor);
    }
    else if (strcmp(command, "top") == 0) {
        jumpToStartOfFile(editor);
    }
    else if (strcmp(command, "bottom") == 0) {
        jumpToEndOfFile(editor);
    }
    else if (strcmp(command, "find") == 0) {
        char *text = input + strlen(command);
        while (*text == ' ') ++text;
        findText(editor, text);
    }
    else if (strcmp(command, "replace") == 0) {
        char oldText[400], newText[400];
        if (sscanf(input + strlen(command), "%399s %399s",
                   oldText, newText) == 2)
            replaceText(editor, oldText, newText);
        else
            printf("Usage: replace <old> <new>\n");
    }
    else if (strcmp(command, "open") == 0) {
        if (sscanf(input + strlen(command), "%1023s", arg) == 1)
            openFile(editor, arg);
        else
            printf("Usage: open <filename>\n");
    }
    else if (strcmp(command, "save") == 0) {
        if (sscanf(input + strlen(command), "%1023s", arg) == 1)
            saveFile(editor, arg);
        else
            printf("Usage: save <filename>\n");
    }
    else if (strcmp(command, "help") == 0) {
        printHelp();
    }
    else {
        printf("Unknown command '%s'. Type 'help'.\n", command);
    }
}

/* The following helpers are kept private to this module. */
Node *textEditorCreateNode(const char *text) { return createNode(text); }
void textEditorInsertNodeAfter(TextEditor *e, Node *c, Node *n)
{ insertNodeAfter(e, c, n); }
void textEditorDeleteNode(TextEditor *e, Node *n)
{ deleteNode(e, n); }


int main(void)
{
    TextEditor editor;
    char input[1024];

    initializeEditor(&editor);

    printf("\n============================================================\n");
    printf("                    TEXT EDITOR v1.0\n");
    printf("============================================================\n");
    printf("Type 'help' to see available commands.\n");

    while (1) {
        printf("\nEnter command: ");

        if (!fgets(input, sizeof(input), stdin))
            break;

        input[strcspn(input, "\n")] = '\0';

        if (input[0] == '\0')
            continue;

        if (strcmp(input, "exit") == 0) {
            printf("Goodbye! Thank you for using Text Editor v1.0\n");
            break;
        }

        handleCommand(&editor, input);
    }

    freeEditor(&editor);
    return 0;
}
