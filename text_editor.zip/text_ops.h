#ifndef TEXT_OPS_H
#define TEXT_OPS_H

#include "text_editor.h"

void insertText(TextEditor *editor, const char *text, int recordHistory);
void deleteCharacters(TextEditor *editor, int count, int recordHistory);
void copyText(TextEditor *editor, int count);
void cutText(TextEditor *editor, int count);
void pasteText(TextEditor *editor);

#endif
