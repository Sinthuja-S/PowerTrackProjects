#ifndef TEXT_EDITOR_H
#define TEXT_EDITOR_H

#include "redo_undo.h"

typedef struct Node {
    char *text;
    struct Node *prev;
    struct Node *next;
} Node;

typedef struct {
    Node *head;
    Node *tail;
    Node *cursor;
    int cursorLine;
    int cursorPos;
    DynamicArrayStack undoStack;
    DynamicArrayStack redoStack;
    char *clipboard;
} TextEditor;

void initializeEditor(TextEditor *editor);
void freeEditor(TextEditor *editor);
void clearDocument(TextEditor *editor);
int getLineNumber(TextEditor *editor, Node *node);
void updateCursorLine(TextEditor *editor);
void displayText(TextEditor *editor);
void showCursorPosition(TextEditor *editor);
void printHelp(void);
void handleCommand(TextEditor *editor, char *input);
void undoEditor(TextEditor *editor);
void redoEditor(TextEditor *editor);

#endif
